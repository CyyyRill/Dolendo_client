<template>
    <navigation/>
    <NuxtLayout name="subscription">
    </NuxtLayout>
    
</template> 