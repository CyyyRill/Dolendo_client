<template>
    <navigation/>
    <Listbox as="div" v-model="selected">
        <ListboxLabel class="block text-sm font-medium leading-6 text-gray-900 container mx-auto">Select Roster</ListboxLabel>
        <div class="relative mt-2 container mx-auto">
            <ListboxButton
                class="relative w-full cursor-default rounded-md bg-white py-1.5 pl-3 pr-10 text-left text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 focus:outline-none focus:ring-2 focus:ring-indigo-500 sm:text-sm sm:leading-6">
                <span class="flex items-center">
                    <img :src="selected.avatar" alt="" class="h-5 w-5 flex-shrink-0 rounded-full" />
                    <span class="ml-3 block truncate">{{ selected.name }}</span>
                </span>
                <span class="pointer-events-none absolute inset-y-0 right-0 ml-3 flex items-center pr-2">
                    <ChevronUpDownIcon class="h-5 w-5 text-gray-400" aria-hidden="true" />
                </span>
            </ListboxButton>

            <transition leave-active-class="transition ease-in duration-100" leave-from-class="opacity-100"
                leave-to-class="opacity-0">
                <ListboxOptions
                    class="absolute z-10 mt-1 max-h-56 w-full overflow-auto rounded-md bg-white py-1 text-base shadow-lg ring-1 ring-black ring-opacity-5 focus:outline-none sm:text-sm">
                    <ListboxOption as="template" v-for="person in people" :key="person.id" :value="person"
                        v-slot="{ active, selected }">
                        <li
                            :class="[active ? 'bg-indigo-600 text-white' : 'text-gray-900', 'relative cursor-default select-none py-2 pl-3 pr-9']">
                            <div class="flex items-center">
                                <img :src="person.avatar" alt="" class="h-5 w-5 flex-shrink-0 rounded-full" />
                                <span :class="[selected ? 'font-semibold' : 'font-normal', 'ml-3 block truncate']">{{
                                    person.name }}</span>
                            </div>

                            <span v-if="selected"
                                :class="[active ? 'text-white' : 'text-indigo-600', 'absolute inset-y-0 right-0 flex items-center pr-4']">
                                <CheckIcon class="h-5 w-5" aria-hidden="true" />
                            </span>
                        </li>
                    </ListboxOption>
                </ListboxOptions>
            </transition>
        </div>
    </Listbox>
</template>
  
<script setup>
import { ref } from 'vue'
import { Listbox, ListboxButton, ListboxLabel, ListboxOption, ListboxOptions } from '@headlessui/vue'
import { CheckIcon, ChevronUpDownIcon } from '@heroicons/vue/20/solid'

const people = [
    {
        id: 1,
        name: 'john uber',
        avatar:
            'https://img.kpopjuice.com/member/684245793f3b3973bc3dfeb730923760_m.jpg',
    },
    {
        id: 2,
        name: 'uber drive',
        avatar:
            'https://thumbs.dreamstime.com/b/profile-shot-school-going-teenager-26978238.jpg',
    },
    {
        id: 3,
        name: 'gofe jake',
        avatar:
            'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQEsN7uHyVN6q3SNE403rX6evHXe8beWvh39q1XBygetA&s',
    },
    {
        id: 4,
        name: 'Tom holen',
        avatar:
            'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSeYA6U95cI59wTFnIIL9VHKLYrvOsFh8c6vP-Vte29Rg&s0',
    },
    {
        id: 5,
        name: 'megan Fox',
        avatar:
            'https://cdn.britannica.com/75/191075-050-DC41EAFD/Megan-Fox-2012.jpg',
    },
    {
        id: 6,
        name: 'hale scot',
        avatar:
            'https://media.vogue.co.uk/photos/5d54aaa3c0212c0008c4bc02/master/pass/original',
    },
    {
        id: 7,
        name: 'Carl kor',
        avatar:
            'https://www.nhm.ac.uk/content/dam/nhmwww/discover/human-evolution/homo-erectus/turkana-boy-full-width.jpg.thumb.1160.1160.jpg',
    },
    {
        id: 8,
        name: 'hannah rot',
        avatar:
            'https://images.unsplash.com/photo-1531427186611-ecfd6d936c79?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80',
    },
    {
        id: 9,
        name: 'sam hor',
        avatar:
            'https://people.com/thmb/gquPbhDtNGjvTsiidPSJcOTEias=/1500x0/filters:no_upscale():max_bytes(150000):strip_icc():focal(749x0:751x2)/0ADaniel-B.-Sheehan-3ddce299c08147488adc68aa7d9a8e6d.jpg',
    },
    {
        id: 10,
        name: 'rawr rawr',
        avatar:
            'https://i.pinimg.com/736x/27/b7/83/27b78322ff78d9514d1b61f37bfe55ac.jpg',
    },
]

const selected = ref(people[3])
</script>