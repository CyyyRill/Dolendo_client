<template>
  <nav class= "bg-white">
    <div class="mx-auto px-4 py-2 pb-5 pt-5 flex  items-center container ">
      <nuxt-link to="/" class=" text-black text-xl font-bold ">Shinru</nuxt-link>
      <div class="mx-32 pl-60">
        <nuxt-link to="/" class="text-black hover:text-gray-400 px-3 py-2 rounded-md">Home</nuxt-link>
        <nuxt-link to="/about" class="text-black hover:text-gray-400 px-3 py-2 rounded-md">About</nuxt-link>
        <nuxt-link to="/contact" class="text-black hover:text-gray-400 px-3 py-2 rounded-md">Contact</nuxt-link>
        <nuxt-link to="/register" class="text-black hover:text-gray-400 px-3 py-2 rounded-md">Subscribe</nuxt-link>
        <nuxt-link to="/rosters" class="text-black hover:text-gray-400 px-3 py-2 rounded-md">Rosters</nuxt-link>
      </div>
    </div>
  </nav>
</template>

<script>
export default {
  // No data or methods needed for this component
}
</script>

<style scoped>
/* Add additional styles here if needed */
</style>