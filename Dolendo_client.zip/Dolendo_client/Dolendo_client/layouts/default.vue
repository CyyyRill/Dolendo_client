<template>
  <div class="container mx-auto px-4 py-8 pt-10">

    <section class="grid grid-cols-1 md:grid-cols-2 gap-4">
      <div class=" border-2 border-grey rounded-md p-4">
        <h2 class="text-lg font-medium mb-2">The Intolerance Network</h2>
        <p >
          Over 17,000 documents from HazteOir and CitizenGO, Spanish right-wing c
          ampaigning organizations. Their links to Spain's far-right political party Vox and the Mexican sect El Yunque are well documented. These documents include HazteOir founding CitizenGo in 2013 to expand their reach, as well as their o
          rganzing of the 2012 World Congress of Families, an influential American far-right platform
        </p>
      </div>
      <div class="border-2 border-grey rounded-md p-4">
        <h2 class="text-lg font-medium mb-2">AmazonAtlas</h2>
        <p>
          Today, 11 October 2018, WikiLeaks publishes a "Highly Confidential" internal document from the 
          cloud computing provider Amazon. The document from late 2015 lists the addresses and some operational details
           of over one hundred data centers spread across fifteen cities in nine countries. To accompany this document, WikiLeaks also
           created a map showing where Amazon’s data centers are located.
        </p>
      </div>
    </section>
    <button type="button" class=" border-2 border-black text-black font-bold py-2 px-4 rounded mt-8">
      Learn More
    </button>
  </div>
</template>

<script>
export default {
  // No data or methods needed for this basic layout
}
</script>

<style scoped>
/* Add additional styles here if needed */
</style>