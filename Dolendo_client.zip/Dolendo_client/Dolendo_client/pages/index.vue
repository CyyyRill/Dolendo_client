<template>
    <navigation/>
   <NuxtLayout name="default">
    </NuxtLayout>
    
</template>

<script setup>
import { BellIcon } from '@heroicons/vue/24/outline'
</script>