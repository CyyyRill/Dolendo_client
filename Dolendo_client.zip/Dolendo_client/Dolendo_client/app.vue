<template>
  <div>
    <NuxtPage/>
  </div>
</template>
