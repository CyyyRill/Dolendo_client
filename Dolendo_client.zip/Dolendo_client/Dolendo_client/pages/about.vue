<template>
    <navigation/>
    <NuxtLayout name="about">
    </NuxtLayout>
    
  </template>
  
  <script>
  export default {
    // No data or methods needed for this basic example
  }
  </script>
  
  <style scoped>
  .about {
    /* Add styles for your About page here */
    padding: 2rem;
  }
  </style>