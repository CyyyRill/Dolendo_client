<template>
  <div class="about container mx-auto">
    <h1 class="text-lg font-medium mb-2">What is an about us page?</h1>
    <p>An About Us page exists to share a business’ story and history and provide a deeper connection with customers.

Consumers want to know the team behind the brand they are supporting. An About Us page provides the perfect real estate to pull back the curtain and reveal who is working behind the scenes.

Most importantly, though, an About Us page facilitates trust between the consumer and the business.

More than 33% of consumers say that “trust” is a core factor when deciding which businesses to support.

With an About Us page, you can begin to form an emotional relationship with customers and engage with them on a deeper level.

So how can you create one that resonates? Let’s look at some of the components you need to include in your About Us page.
    </p>
    <p>Feel free to add images, videos, or other content to make your About page 
      more engaging.</p>
  </div>
</template>

<script>
export default {
  // No data or methods needed for this basic example
}
</script>

<style scoped>
.about {
  /* Add styles for your About page here */
  padding: 2rem;
}
</style>