<template>
  <div class="pt-10 bg-white shadow sm:rounded-lg container mx-auto">
        <div class="px-4 py-5 sm:p-6">
            <h3 class="text-lg font-medium mb-2 pb-4">Subscription</h3>
            <div class="mt-2 max-w-xl text-sm text-gray-500">
                <p>wewerwtewtrwetrwetrwetrwetersdfggxsxsggxsgsgsdfuidfuidfuidfuidfuiqwejhgfasdkjgdfjkasd
                    sdfashdvgfasdjfkasdgfjkgasjkgfasdjkgfasdjkgdkj.</p>
            </div>
            <div class="mt-5">
                <button type="button"
                    class=" border-2 border-black text-grey font-bold py-2 px-4 rounded mt-8">Change
                    plan</button>
            </div>
        </div>
    </div>
</template>